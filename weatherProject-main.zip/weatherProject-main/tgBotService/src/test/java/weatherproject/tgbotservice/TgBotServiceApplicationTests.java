package weatherproject.tgbotservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TgBotServiceApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
