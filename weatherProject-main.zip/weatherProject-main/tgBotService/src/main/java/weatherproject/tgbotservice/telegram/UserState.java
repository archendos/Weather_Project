package weatherproject.tgbotservice.telegram;

public enum UserState {
    START,
    HAVE_SETTED_CITY
}
